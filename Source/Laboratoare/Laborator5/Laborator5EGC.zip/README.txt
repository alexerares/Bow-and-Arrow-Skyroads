Pentru a modifica FOV-ul am pus tastele N si M.

Pentru a modifica inaltimea ferestrei de proiectie am pus tastele
K si L.

La exercitiu 6 cred ca se vad direct celelalte obiecte.