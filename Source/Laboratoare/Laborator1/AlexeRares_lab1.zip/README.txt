Pentru a schimba culoarea poti apasa pe f si pe k.
Pentru a schimba obiectul apasa pe H.
Am facut un arcas sa mearga pe wasdqe.
La bonus nu am stiut daca trebuie sa se invarta doar cand apas
un buton asa ca l-am facut sa se invarta mereu.