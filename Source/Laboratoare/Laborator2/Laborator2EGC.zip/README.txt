2. Tetraedrul de mai jos este pentru acest subiect, am facut si un cub.

3. Tetraedrul de deasupra e pentru acest subiect.

6. Patratul este roz si e mai i spate.

7. La cerc poti schimba tu valorile din fisierul.h.